package org.mirgar.android.mgclient.data.models

import org.mirgar.android.mgclient.data.entity.AppealPhoto
import java.io.File

class AppealPhotoWithFile(val appealPhoto: AppealPhoto, val file: File)