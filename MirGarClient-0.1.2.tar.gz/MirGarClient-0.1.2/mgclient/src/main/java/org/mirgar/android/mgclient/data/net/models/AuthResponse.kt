package org.mirgar.android.mgclient.data.net.models

class AuthResponse {
    var auth: String? = null
    var code: String? = null
    var id: String? = null
    var jwt: String? = null
}
