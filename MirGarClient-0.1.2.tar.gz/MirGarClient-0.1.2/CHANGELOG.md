# Changelog

## Unreleased

### Breaking changes

### New Features

## 0.1.1

### Breaking changes
- Injecting view models using single view model factory
- `EditAppealFragment` now accepts `appealId` param optionally

### New Features
- CRUD for `Appeal`
- Tracking changes for `EditAppeal` view model

## 0.1.0

### Breaking changes

### New Features
- `EditAppealFragment` data binding
- `AppDatabase` with DAO using `Room` framework
- Navigation using `Navigation` framework
